@extends('layouts.app')

@section('content')
    <h1 style="text-align: center">Create Post</h1>


@endsection
