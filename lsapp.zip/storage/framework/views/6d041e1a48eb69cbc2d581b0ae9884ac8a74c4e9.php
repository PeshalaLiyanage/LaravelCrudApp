<?php $__env->startSection('content'); ?>
    <h1 style="text-align: center"><?php echo e($post ->title); ?></h1>
    <small>Written at <?php echo e($post -> created_at); ?></small>
    <div>
        <?php echo e($post -> body); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\laravel_projects\lsapp\resources\views/posts/show.blade.php ENDPATH**/ ?>