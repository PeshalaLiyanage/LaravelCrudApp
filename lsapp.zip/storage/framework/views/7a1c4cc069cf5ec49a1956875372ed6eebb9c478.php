<?php $__env->startSection('content'); ?>
    <h1>About</h1>
    <p>This is about</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\laravel_projects\lsapp\resources\views/pages/about.blade.php ENDPATH**/ ?>